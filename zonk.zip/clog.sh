#!/bin/bash
echo > /var/log/xray/access.log
